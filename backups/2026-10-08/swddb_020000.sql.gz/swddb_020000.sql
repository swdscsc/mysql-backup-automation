-- MySQL dump 10.13  Distrib 5.7.44
USE `swddb`;
CREATE TABLE `classscore` (
  `classname` varchar(16) DEFAULT NULL,
  `avgScore` double DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `classscore` VALUES ('计科1班',85.4),('计科2班',82.1);
CREATE TABLE `student` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO `student` VALUES (1,'zhangsan'),(2,'lisi');
-- Dump completed on 2026-10-08 02:00:00
